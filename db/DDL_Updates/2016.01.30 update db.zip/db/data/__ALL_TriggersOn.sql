alter table LISTTYPE enable all triggers;
