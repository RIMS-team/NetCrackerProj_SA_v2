@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\__ALL_DDL.sql"
