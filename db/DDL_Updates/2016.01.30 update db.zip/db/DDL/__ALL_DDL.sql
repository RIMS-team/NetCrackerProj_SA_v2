prompt ======================
prompt     dm_notebook.spc
@@"C:\temp\db\DDL\dm_notebook.spc"
prompt ======================
prompt     dm_ord_status.spc
@@"C:\temp\db\DDL\dm_ord_status.spc"
prompt ======================
prompt     dm_param.spc
@@"C:\temp\db\DDL\dm_param.spc"
prompt ======================
prompt     dm_notif_templ.spc
@@"C:\temp\db\DDL\dm_notif_templ.spc"
prompt ======================
prompt     dm_notification.spc
@@"C:\temp\db\DDL\dm_notification.spc"
prompt ======================
prompt     dm_inv_status.spc
@@"C:\temp\db\DDL\dm_inv_status.spc"
prompt ======================
prompt     dm_access_card.spc
@@"C:\temp\db\DDL\dm_access_card.spc"
prompt ======================
prompt     dm_util.spc
@@"C:\temp\db\DDL\dm_util.spc"
prompt ======================
prompt     dm_order.spc
@@"C:\temp\db\DDL\dm_order.spc"
prompt ======================
prompt     dm_user.spc
@@"C:\temp\db\DDL\dm_user.spc"
prompt ======================
prompt     dm_employee.spc
@@"C:\temp\db\DDL\dm_employee.spc"
prompt ======================
prompt     dm_util.bdy
@@"C:\temp\db\DDL\dm_util.bdy"
prompt ======================
prompt     dm_user.bdy
@@"C:\temp\db\DDL\dm_user.bdy"
prompt ======================
prompt     dm_param.bdy
@@"C:\temp\db\DDL\dm_param.bdy"
prompt ======================
prompt     dm_ord_status.bdy
@@"C:\temp\db\DDL\dm_ord_status.bdy"
prompt ======================
prompt     dm_inv_status.bdy
@@"C:\temp\db\DDL\dm_inv_status.bdy"
prompt ======================
prompt     dm_employee.bdy
@@"C:\temp\db\DDL\dm_employee.bdy"
prompt ======================
prompt     dm_access_card.bdy
@@"C:\temp\db\DDL\dm_access_card.bdy"
prompt ======================
prompt     dm_notebook.bdy
@@"C:\temp\db\DDL\dm_notebook.bdy"
prompt ======================
prompt     dm_order.bdy
@@"C:\temp\db\DDL\dm_order.bdy"
prompt ======================
prompt     dm_notif_templ.bdy
@@"C:\temp\db\DDL\dm_notif_templ.bdy"
prompt ======================
prompt     dm_notification.bdy
@@"C:\temp\db\DDL\dm_notification.bdy"
prompt ======================
