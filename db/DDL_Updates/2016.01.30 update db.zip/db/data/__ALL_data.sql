@@"C:\temp\db\data\LISTTYPE.data1"
