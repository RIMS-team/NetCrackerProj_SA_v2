alter table LISTTYPE disable all triggers;
