prompt ======================
prompt     clob_tbl.tps
@@"C:\temp\db\DDL\clob_tbl.tps"
prompt ======================
prompt     varchar2_100_table_type.tps
@@"C:\temp\db\DDL\varchar2_100_table_type.tps"
prompt ======================
prompt     listtype.tab
@@"C:\temp\db\DDL\listtype.tab"
prompt ======================
prompt     objtype.tab
@@"C:\temp\db\DDL\objtype.tab"
prompt ======================
prompt     sdb_users.tab
@@"C:\temp\db\DDL\sdb_users.tab"
prompt ======================
prompt     sdb_orders.tab
@@"C:\temp\db\DDL\sdb_orders.tab"
prompt ======================
prompt     param.tab
@@"C:\temp\db\DDL\param.tab"
prompt ======================
prompt     attrtype.tab
@@"C:\temp\db\DDL\attrtype.tab"
prompt ======================
prompt     admin_table_type.tab
@@"C:\temp\db\DDL\admin_table_type.tab"
prompt ======================
prompt     admin_table.tab
@@"C:\temp\db\DDL\admin_table.tab"
prompt ======================
prompt     objects.tab
@@"C:\temp\db\DDL\objects.tab"
prompt ======================
prompt     attributes.tab
@@"C:\temp\db\DDL\attributes.tab"
prompt ======================
prompt     objreference.tab
@@"C:\temp\db\DDL\objreference.tab"
prompt ======================
prompt     notif_templ.tab
@@"C:\temp\db\DDL\notif_templ.tab"
prompt ======================
prompt     dm_ord_status.spc
@@"C:\temp\db\DDL\dm_ord_status.spc"
prompt ======================
prompt     dm_notif_templ.spc
@@"C:\temp\db\DDL\dm_notif_templ.spc"
prompt ======================
prompt     dm_order.spc
@@"C:\temp\db\DDL\dm_order.spc"
prompt ======================
prompt     dm_param.spc
@@"C:\temp\db\DDL\dm_param.spc"
prompt ======================
prompt     dm_user.spc
@@"C:\temp\db\DDL\dm_user.spc"
prompt ======================
prompt     dm_util.spc
@@"C:\temp\db\DDL\dm_util.spc"
prompt ======================
prompt     dm_test_data.spc
@@"C:\temp\db\DDL\dm_test_data.spc"
prompt ======================
prompt     dm_umbrella.spc
@@"C:\temp\db\DDL\dm_umbrella.spc"
prompt ======================
prompt     dm_inv_status.spc
@@"C:\temp\db\DDL\dm_inv_status.spc"
prompt ======================
prompt     dm_notebook.spc
@@"C:\temp\db\DDL\dm_notebook.spc"
prompt ======================
prompt     dm_employee.spc
@@"C:\temp\db\DDL\dm_employee.spc"
prompt ======================
prompt     dm_access_card.spc
@@"C:\temp\db\DDL\dm_access_card.spc"
prompt ======================
prompt     dm_admin_util.spc
@@"C:\temp\db\DDL\dm_admin_util.spc"
prompt ======================
prompt     dm_notification.spc
@@"C:\temp\db\DDL\dm_notification.spc"
prompt ======================
prompt     sdb_emp_data_processing.prc
@@"C:\temp\db\DDL\sdb_emp_data_processing.prc"
prompt ======================
prompt     sdb_data_processing.prc
@@"C:\temp\db\DDL\sdb_data_processing.prc"
prompt ======================
prompt     seq_attrtype.seq
@@"C:\temp\db\DDL\seq_attrtype.seq"
prompt ======================
prompt     seq_objtype.seq
@@"C:\temp\db\DDL\seq_objtype.seq"
prompt ======================
prompt     seq_admin_table.seq
@@"C:\temp\db\DDL\seq_admin_table.seq"
prompt ======================
prompt     seq_listtype.seq
@@"C:\temp\db\DDL\seq_listtype.seq"
prompt ======================
prompt     seq_objects.seq
@@"C:\temp\db\DDL\seq_objects.seq"
prompt ======================
prompt     trg_objects_bi.trg
@@"C:\temp\db\DDL\trg_objects_bi.trg"
prompt ======================
prompt     admin_table_biu.trg
@@"C:\temp\db\DDL\admin_table_biu.trg"
prompt ======================
prompt     trg_objtype_bi.trg
@@"C:\temp\db\DDL\trg_objtype_bi.trg"
prompt ======================
prompt     trg_listtype_bi.trg
@@"C:\temp\db\DDL\trg_listtype_bi.trg"
prompt ======================
prompt     sdb_orders_validation.trg
@@"C:\temp\db\DDL\sdb_orders_validation.trg"
prompt ======================
prompt     sdb_users_validation.trg
@@"C:\temp\db\DDL\sdb_users_validation.trg"
prompt ======================
prompt     trg_attrtype_bi.trg
@@"C:\temp\db\DDL\trg_attrtype_bi.trg"
prompt ======================
prompt     dm_notif_templ.bdy
@@"C:\temp\db\DDL\dm_notif_templ.bdy"
prompt ======================
prompt     dm_notification.bdy
@@"C:\temp\db\DDL\dm_notification.bdy"
prompt ======================
prompt     dm_ord_status.bdy
@@"C:\temp\db\DDL\dm_ord_status.bdy"
prompt ======================
prompt     dm_order.bdy
@@"C:\temp\db\DDL\dm_order.bdy"
prompt ======================
prompt     dm_notebook.bdy
@@"C:\temp\db\DDL\dm_notebook.bdy"
prompt ======================
prompt     dm_admin_util.bdy
@@"C:\temp\db\DDL\dm_admin_util.bdy"
prompt ======================
prompt     dm_access_card.bdy
@@"C:\temp\db\DDL\dm_access_card.bdy"
prompt ======================
prompt     dm_inv_status.bdy
@@"C:\temp\db\DDL\dm_inv_status.bdy"
prompt ======================
prompt     dm_employee.bdy
@@"C:\temp\db\DDL\dm_employee.bdy"
prompt ======================
prompt     dm_user.bdy
@@"C:\temp\db\DDL\dm_user.bdy"
prompt ======================
prompt     dm_util.bdy
@@"C:\temp\db\DDL\dm_util.bdy"
prompt ======================
prompt     dm_umbrella.bdy
@@"C:\temp\db\DDL\dm_umbrella.bdy"
prompt ======================
prompt     dm_param.bdy
@@"C:\temp\db\DDL\dm_param.bdy"
prompt ======================
prompt     dm_test_data.bdy
@@"C:\temp\db\DDL\dm_test_data.bdy"
prompt ======================
prompt     attrtype.fk
@@"C:\temp\db\DDL\attrtype.fk"
prompt ======================
prompt     attributes.fk
@@"C:\temp\db\DDL\attributes.fk"
prompt ======================
prompt     admin_table.fk
@@"C:\temp\db\DDL\admin_table.fk"
prompt ======================
prompt     objreference.fk
@@"C:\temp\db\DDL\objreference.fk"
prompt ======================
prompt     notif_templ.fk
@@"C:\temp\db\DDL\notif_templ.fk"
prompt ======================
prompt     objtype.fk
@@"C:\temp\db\DDL\objtype.fk"
prompt ======================
prompt     objects.fk
@@"C:\temp\db\DDL\objects.fk"
prompt ======================
