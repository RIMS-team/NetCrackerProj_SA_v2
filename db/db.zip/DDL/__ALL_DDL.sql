prompt ======================
prompt     clob_tbl.tps
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\clob_tbl.tps"
prompt ======================
prompt     varchar2_100_table_type.tps
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\varchar2_100_table_type.tps"
prompt ======================
prompt     objreference.tab
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\objreference.tab"
prompt ======================
prompt     listtype.tab
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\listtype.tab"
prompt ======================
prompt     objects.tab
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\objects.tab"
prompt ======================
prompt     attributes.tab
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\attributes.tab"
prompt ======================
prompt     objtype.tab
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\objtype.tab"
prompt ======================
prompt     attrtype.tab
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\attrtype.tab"
prompt ======================
prompt     dm_ord_status.spc
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_ord_status.spc"
prompt ======================
prompt     dm_order.spc
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_order.spc"
prompt ======================
prompt     dm_notification.spc
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_notification.spc"
prompt ======================
prompt     dm_user.spc
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_user.spc"
prompt ======================
prompt     dm_umbrella.spc
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_umbrella.spc"
prompt ======================
prompt     dm_test_data.spc
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_test_data.spc"
prompt ======================
prompt     dm_inv_status.spc
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_inv_status.spc"
prompt ======================
prompt     dm_employee.spc
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_employee.spc"
prompt ======================
prompt     dm_access_card.spc
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_access_card.spc"
prompt ======================
prompt     dm_notebook.spc
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_notebook.spc"
prompt ======================
prompt     seq_attrtype.seq
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\seq_attrtype.seq"
prompt ======================
prompt     seq_listtype.seq
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\seq_listtype.seq"
prompt ======================
prompt     seq_objtype.seq
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\seq_objtype.seq"
prompt ======================
prompt     seq_objects.seq
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\seq_objects.seq"
prompt ======================
prompt     trg_objtype_bi.trg
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\trg_objtype_bi.trg"
prompt ======================
prompt     trg_attrtype_bi.trg
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\trg_attrtype_bi.trg"
prompt ======================
prompt     trg_listtype_bi.trg
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\trg_listtype_bi.trg"
prompt ======================
prompt     trg_objects_bi.trg
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\trg_objects_bi.trg"
prompt ======================
prompt     dm_umbrella.bdy
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_umbrella.bdy"
prompt ======================
prompt     dm_inv_status.bdy
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_inv_status.bdy"
prompt ======================
prompt     dm_test_data.bdy
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_test_data.bdy"
prompt ======================
prompt     dm_ord_status.bdy
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_ord_status.bdy"
prompt ======================
prompt     dm_notebook.bdy
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_notebook.bdy"
prompt ======================
prompt     dm_notification.bdy
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_notification.bdy"
prompt ======================
prompt     dm_employee.bdy
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_employee.bdy"
prompt ======================
prompt     dm_order.bdy
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_order.bdy"
prompt ======================
prompt     dm_user.bdy
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_user.bdy"
prompt ======================
prompt     dm_access_card.bdy
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\dm_access_card.bdy"
prompt ======================
prompt     attributes.fk
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\attributes.fk"
prompt ======================
prompt     objreference.fk
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\objreference.fk"
prompt ======================
prompt     objects.fk
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\objects.fk"
prompt ======================
prompt     attrtype.fk
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\attrtype.fk"
prompt ======================
prompt     objtype.fk
@@"C:\Work_J\NetCrackerProj_SA_v2\db\DDL\objtype.fk"
prompt ======================
