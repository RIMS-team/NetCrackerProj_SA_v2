alter table ATTRIBUTES enable constraint CON_AATTR_ID;
alter table ATTRIBUTES enable constraint CON_AOBJECT_ID;
alter table ATTRTYPE enable constraint CON_ATTR_OBJECT_TYPE_ID;
alter table ATTRTYPE enable constraint CON_ATTR_OBJECT_TYPE_ID_REF;
alter table OBJECTS enable constraint CON_OBJ_TYPE_ID;
alter table OBJECTS enable constraint CON_PARENTS_ID;
alter table OBJTYPE enable constraint CON_PARENT_ID;
