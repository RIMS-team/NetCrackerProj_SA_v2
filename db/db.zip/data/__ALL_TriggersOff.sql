alter table LISTTYPE disable all triggers;
alter table OBJTYPE disable all triggers;
alter table ATTRTYPE disable all triggers;
alter table ATTRIBUTES disable all triggers;
alter table OBJECTS disable all triggers;
