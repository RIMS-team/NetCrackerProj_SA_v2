alter table LISTTYPE enable all triggers;
alter table OBJTYPE enable all triggers;
alter table ATTRTYPE enable all triggers;
alter table ATTRIBUTES enable all triggers;
alter table OBJECTS enable all triggers;
